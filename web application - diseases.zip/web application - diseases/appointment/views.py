from django.shortcuts import render, redirect
from django.urls.conf import re_path
from .models import * 
from .forms import * 
from django.views.generic import ListView, CreateView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from user_profile.models import *
from datetime import datetime, timedelta  
# Create your views here.
from datetime import date
from django.contrib import messages

from sklearn import tree
import numpy as np
import pandas as pd
from django.http import JsonResponse


def appointments_list(request):
    if request.user.is_doctor:
        get_doctor_instance=DoctorProfile.objects.get(user_id=request.user.id)
        apps=Appointment.objects.filter(doctor=get_doctor_instance)
        context={'apps': apps}
        return render(request, 'appointment/appointment_list.html',context)
    get_patient_instance=PatientProfile.objects.get(user_id=request.user.id)
    apps=Appointment.objects.filter(patient=get_patient_instance)
    context={'apps': apps}
    return render(request, 'appointment/appointment_list.html',context)



#############======================================================#################
#############============ Function for book an appointmen =========#################
#############======================================================#################

# new appointment code start from here
def book_an_appointment(request):
    current_time =  datetime.now().strftime('%H:%M:%S')
    if request.POST:

        form=DepartmentForm(request.POST)
        if form.is_valid():
            department=form.cleaned_data['department']
            symptoms=request.POST.get('symptoms')
            book_date=request.POST.get('book_date')
            if book_date=='':
                messages.success(request,'Please Choose a date')
                return redirect('appointment:book_an_appointment')
                
            get_doctors=DoctorProfile.objects.filter(department=department)

            if get_doctors:
                pass
            else:
                messages.success(request,'No Doctor Availble yet Try another time')
                return redirect('appointment:book_an_appointment')
            
            print("All Doctor Via Departments",get_doctors)
            for doctor in get_doctors:
                get_id=doctor.id
                get_doctor=DoctorProfile.objects.get(id=get_id)
                print("Doctor Instance IS",get_doctor)
                
                start_time=get_doctor.shift_start_time
                endtime=get_doctor.shift_end_time

                print("Timing",start_time,endtime)
 
                patient=PatientProfile.objects.get(user=request.user) 



                if book_date:
                    if book_date < str(date.today()):
                        messages.error(request,'Please choose  right date')
                        context ={'form':DepartmentForm()}
                        return render(request, 'appointment/appointment_create.html',context)

                    else:
                        date_appointment=Appointment.objects.filter(book_date=book_date).filter(doctor=get_doctor)
                        print("date is this",date_appointment)
                        

                        if date_appointment:
                            last_appointment_id=Appointment.objects.filter(book_date=book_date).filter(doctor=get_doctor).last()
                            last_appointment_time=last_appointment_id.appointment_time    
                            
                            update_time = last_appointment_time.replace(hour=(last_appointment_time.hour+1) % 24)

                           
              
                            if str(update_time) > str(endtime) :
                                context ={'form':DepartmentForm()}
                                messages.success(request,"No doctor available In this date please choose another date")
                                return render(request, 'appointment/appointment_create.html',context)
                            #end from here
                            else:
  
                                appoint=Appointment(
                                    book_time=current_time,
                                    appointment_time=update_time,
                                    symptom =symptoms,
                                    patient = patient,
                                    doctor = get_doctor,
                                    department=department,
                                    book_date=book_date,)

                                appoint.save()
                                

                            messages.success(request,f"You have an appointment on date {book_date} at {update_time}")
                            return redirect('appointment:book_an_appointment')
                            pass
                        else:
                            print("today date is",date.today())    
                            print("book date is",book_date)    
                            update_time = start_time.replace(hour=(start_time.hour+1) % 24)
                            if str(date.today())==str(book_date):
                                print("yes it was")
                                if str(current_time) > str(update_time):
                                    current_time =  datetime.now()
                                    print(current_time)
                                    #datetime.strptime(current_time,'%H:%M:%S').strftime('%H:%M:%S')
                                    print(type(current_time))
                                
                                    update_time = current_time.replace(hour=(current_time.hour+1) % 24)
                                    appointment=Appointment(
                                        book_time=current_time,
                                        appointment_time=update_time,
                                        symptom =symptoms,
                                        patient = patient,
                                        doctor = get_doctor,
                                        department=department,
                                        book_date=book_date,
                                            )
                                    appointment.save()
                                    messages.success(request,f'You have an appointment now at {update_time}')
                                    return redirect('appointment:book_an_appointment') 
                                else:
                                    appointment=Appointment(
                                        book_time=current_time,
                                        appointment_time=update_time,
                                        symptom =symptoms,
                                        patient = patient,
                                        doctor = get_doctor,
                                        department=department,
                                        book_date=book_date,
                                            )
                                    appointment.save()



                        appoint=Appointment(
                                book_time=current_time,
                                appointment_time=update_time,
                                symptom =symptoms,
                                patient = patient,
                                doctor = get_doctor,
                                department=department,
                                book_date=book_date,
                                

                            )
                        appoint.save()
                        messages.success(request,f"You have an appointment on date {book_date} at {update_time}")
                        return redirect('appointment:book_an_appointment')                              
                
                # current_time= datetime.now().strftime('%H:%M:%S')   
                # today_date=date.today()
                # check_today_appointment=Appointment.objects.filter(book_date=today_date)
                # if check_today_appointment:
                #     check_doctor=Appointment.objects.filter(doctor=get_doctor)
                #     if check_doctor:
                #         pass



                
                #         if check_today_appointment.exists():
                #             print("today appointment")
                #             time_less_than=''
                #             last_appointment_id=Appointment.objects.filter(doctor=get_doctor).last()
                #             get_previous_appoint_time=last_appointment_id.appointment_time

                               

                                
                                


                #             print("hiii",get_previous_appoint_time)
                #             update_time = get_previous_appoint_time.replace(hour=(get_previous_appoint_time.hour+1) % 24)

                #             if str(current_time) > str(get_previous_appoint_time):
                #                 update_time = current_time.replace(hour=(current_time.hour+1) % 24)
                
                #                 appoint=Appointment(
                #                     book_time=current_time,
                #                     appointment_time=update_time,
                #                     symptom =symptoms,
                #                     patient = patient,
                #                     doctor = get_doctor,
                #                     department=department,
    

                #                                 )
                #                 appoint.save()
                #                 messages.success(request,f'Your have an appointment now {update_time}')
                #                 return redirect('appointment:book_an_appointment')
                #             elif str(update_time) > str(endtime) :
                #                 another_date="choose"
                #                 context ={'form':DepartmentForm(),"choose":another_date}
                #                 messages.success(request,"No doctor available for today please choose another")
                #                 return render(request, 'appointment/appointment_create.html',context)
                #             else:

                #                 appoint=Appointment(
                #                 book_time=current_time,
                #                 appointment_time=update_time,
                #                 symptom =symptoms,
                #                 patient = patient,
                #                 doctor = get_doctor,
                #                 department=department,
    

                #                 )
                #             appoint.save()
                #             messages.success(request,f'Your have an appointment now {update_time}')
                #             return redirect('appointment:book_an_appointment')
                            
                # else:
                       
                
                
                #     update_time = start_time.replace(hour=(start_time.hour+1) % 24)
                
                #     appoint=Appointment(
                #         book_time=current_time,
                #         appointment_time=update_time,
                #         symptom =symptoms,
                #         patient = patient,
                #         doctor = get_doctor,
                #         department=department,
    

                #         )
                #     appoint.save()
                #     messages.success(request,f'Your have an appointment now on {update_time}')
                #     return redirect('appointment:book_an_appointment')
                
                





        
    return render(request, 'appointment/appointment_create.html',{'form':DepartmentForm()})

#new appointment code here

# def appointment_book(request):
#     form=DepartmentForm()
#     if request.POST:
#         form=DepartmentForm(request.POST)
#         if form.is_valid():

#             department=form.cleaned_data['department']
#             symptoms=request.POST.get('symptoms')
#             now = datetime.now()
#             current_time = now.strftime("%H:%M:%S")
#             today_date=date.today()
#             check_today_appointment=Appointment.objects.filter(book_date=today_date).filter(doctor=g)
#             if check_today_appointment.exists():
#                     time_less_than=''
#                     last_appointment_id=Appointment.objects.filter(doctor=g).last()
#                     get_previous_appoint_time=last_appointment_id.appointment_time
#             get_patient_instance=PatientProfile.objects.get(user_id=request.user.id)
            
#             get_doctor=DoctorProfile.objects.filter(department=department)
#             print("doctors",get_doctor)
#             for g in get_doctor:
#                 get_doctor_id=g.id
#                 get_doctor_instance=DoctorProfile.objects.get(id=get_doctor_id)
#                 get_app=Appointment.objects.filter(doctor=g).count()
#                 today_date=date.today()
#                 check_today_appointment=Appointment.objects.filter(book_date=today_date).filter(doctor=g)
#                 print("check_today_appointment",check_today_appointment)
#                 if check_today_appointment.exists():
#                     time_less_than=''
#                     last_appointment_id=Appointment.objects.filter(doctor=g).last()
#                     get_previous_appoint_time=last_appointment_id.appointment_time
#                     tz_info=get_previous_appoint_time.tzinfo
#                     ct_time=datetime.now(tz_info)  

#                     print("last one",datetime.now(tz_info))    

#                     if ct_time > get_previous_appoint_time:

#                         if get_app < 5:
#                             appoint=Appointment(
#                             book_time=current_time,
#                             appointment_time=ct_time + timedelta(hours=1),
#                             symptom =symptoms,
#                             patient = get_patient_instance,
#                             doctor = get_doctor_instance,
#                             department=department,
    

#                                     )
#                             appoint.save()        
#                             messages.success(request,'Your have an appointment now')
#                             return redirect('appointment:appointment_book')        


#                     if get_app < 5:
                    

#                         appoint=Appointment(
#                             book_time=current_time,
#                             appointment_time=get_previous_appoint_time + timedelta(hours=1),
#                             symptom =symptoms,
#                             patient = get_patient_instance,
#                             doctor = get_doctor_instance,
#                             department=department,
    

#                     )
#                         #appoint.save()
#                         messages.success(request,'Your have an appointment now')
#                         return redirect('appointment:appointment_book')
#                     else:
#                         print("no")    
#                 else:
#                     if get_app < 5:
                    
#                         present_time = datetime.now() 
#                         '{:%H:%M:%S}'.format( present_time ) 
#                         updated_time = present_time + timedelta(hours=1)
                           
#                         appoint=Appointment(
#                             book_time=current_time,
#                             appointment_time=updated_time,
#                             symptom =symptoms,
#                             patient = get_patient_instance,
#                             doctor = get_doctor_instance,
#                             department=department,
    

#                                                 )   
#                         appoint.save()
#                         messages.success(request,'Your have an appointment now')
#                         return redirect('appointment:appointment_book')
#                     else:
#                         print("no")

#                         #appoint.save()               

#     context={'form':form}

#     return render(request,'appointment/appointment_create.html',context)

#############============ End of Function to book an appointment ==========##########


def prescription(request ,pk):
    get_appointment=Appointment.objects.filter(id=pk).first()

    if Prescription.objects.filter(appointment=get_appointment).exists():
        messages.success(request,'You have already given a prescription')
        return redirect('appointment:appointments_list')

    


    if request.POST:
        patient = request.POST.get('patient')
        symptoms = request.POST.get('symptom')
        prescription = request.POST.get('prescription')

        print(patient,symptoms,prescription)

        get_patient=PatientProfile.objects.get(user__username=patient)
        get_doctor_instances=DoctorProfile.objects.get(user_id=request.user.id)
        

        pres=Prescription(
            appointment=get_appointment,
            patient= get_patient,
            doctor=get_doctor_instances,
            symptoms=symptoms,
            prescription=prescription,
            date =datetime.now()

        )
        pres.save()
        Appointment.objects.filter(id=pk).update(prescription_added=True)
        messages.info(request, "Prescription addes sucessfully")
        return redirect('appointment:prescription_list')


    context={'apts':get_appointment}
    return render(request, 'appointment/prescription_create.html',context)


def prescription_list(request):
    get_doctor=DoctorProfile.objects.get(user_id=request.user.id)
    lists=Prescription.objects.filter(doctor=get_doctor)
    context={'lists':lists}
    return render(request , 'appointment/prescription_list.html',context)


def medical_history(request):
    get_id=request.GET.get('appointment')
    get_patient_instance=''
    if get_id:
        appointment=Appointment.objects.filter(id=get_id).first()
        get_patient=appointment.patient.id
        get_patient_instance=PatientProfile.objects.filter(id=get_patient).first()
        lists=Prescription.objects.filter(patient=get_patient_instance)
        context={'lists':lists}
        return render(request , 'appointment/medical_history.html',context)


    get_patient_instance=PatientProfile.objects.filter(user_id=request.user.id).first()
    predicts=Predict.objects.filter(patient=get_patient_instance)
    
    lists=Prescription.objects.filter(patient=get_patient_instance)
    context={'lists':lists,'predicts':predicts}

    return render(request , 'appointment/medical_history.html',context)


def update_prescription(request,pk):

    pr=Prescription.objects.get(id=pk)

    if request.POST:
        form=PrescriptionForm(request.POST,instance=pr)
        if form.is_valid:
            form.save()

            messages.success(request, "Prescription updated sucessfully")
            return redirect('appointment:prescription_list')





    form=PrescriptionForm(instance=pr)

    return render(request , 'appointment/update_prescription.html',{'form':form})



def delete_appointment(request,pk):
    Appointment.objects.get(pk=pk).delete()
    messages.success(request, 'Deleted Successfully')
    return redirect('appointment:appointments_list')



# Disease Prediction 




def predict(request):
    return render(request, "Predict/predict.html")
def result(request):
    l1 = ['back_pain', 'constipation', 'abdominal_pain', 'diarrhoea', 'mild_fever', 'yellow_urine',
          'yellowing_of_eyes', 'acute_liver_failure', 'fluid_overload', 'swelling_of_stomach',
          'swelled_lymph_nodes', 'malaise', 'blurred_and_distorted_vision', 'phlegm', 'throat_irritation',
          'redness_of_eyes', 'sinus_pressure', 'runny_nose', 'congestion', 'chest_pain', 'weakness_in_limbs',
          'fast_heart_rate', 'pain_during_bowel_movements', 'pain_in_anal_region', 'bloody_stool',
          'irritation_in_anus', 'neck_pain', 'dizziness', 'cramps', 'bruising', 'obesity', 'swollen_legs',
          'swollen_blood_vessels', 'puffy_face_and_eyes', 'enlarged_thyroid', 'brittle_nails',
          'swollen_extremeties', 'excessive_hunger', 'extra_marital_contacts', 'drying_and_tingling_lips',
          'slurred_speech', 'knee_pain', 'hip_joint_pain', 'muscle_weakness', 'stiff_neck', 'swelling_joints',
          'movement_stiffness', 'spinning_movements', 'loss_of_balance', 'unsteadiness',
          'weakness_of_one_body_side', 'loss_of_smell', 'bladder_discomfort', 'foul_smell_of urine',
          'continuous_feel_of_urine', 'passage_of_gases', 'internal_itching', 'toxic_look_(typhos)',
          'depression', 'irritability', 'muscle_pain', 'altered_sensorium', 'red_spots_over_body', 'belly_pain',
          'abnormal_menstruation', 'dischromic _patches', 'watering_from_eyes', 'increased_appetite', 'polyuria',
          'family_history', 'mucoid_sputum',
          'rusty_sputum', 'lack_of_concentration', 'visual_disturbances', 'receiving_blood_transfusion',
          'receiving_unsterile_injections', 'coma', 'stomach_bleeding', 'distention_of_abdomen',
          'history_of_alcohol_consumption', 'fluid_overload', 'blood_in_sputum', 'prominent_veins_on_calf',
          'palpitations', 'painful_walking', 'pus_filled_pimples', 'blackheads', 'scurring', 'skin_peeling',
          'silver_like_dusting', 'small_dents_in_nails', 'inflammatory_nails', 'blister', 'red_sore_around_nose',
          'yellow_crust_ooze']

    disease = ['Fungal infection', 'Allergy', 'GERD', 'Chronic cholestasis', 'Drug Reaction',
               'Peptic ulcer diseae', 'AIDS', 'Diabetes', 'Gastroenteritis', 'Bronchial Asthma', 'Hypertension',
               ' Migraine', 'Cervical spondylosis',
               'Paralysis (brain hemorrhage)', 'Jaundice', 'Malaria', 'Chicken pox', 'Dengue', 'Typhoid', 'hepatitis A',
               'Hepatitis B', 'Hepatitis C', 'Hepatitis D', 'Hepatitis E', 'Alcoholic hepatitis', 'Tuberculosis',
               'Common Cold', 'Pneumonia', 'Dimorphic hemmorhoids(piles)',
               'Heartattack', 'Varicoseveins', 'Hypothyroidism', 'Hyperthyroidism', 'Hypoglycemia', 'Osteoarthristis',
               'Arthritis', '(vertigo) Paroymsal  Positional Vertigo', 'Acne', 'Urinary tract infection', 'Psoriasis',
               'Impetigo']

    l2 = []
    for x in range(0, len(l1)):
        l2.append(0)

    # Training DATA
    df = pd.read_csv("Training.csv")

    df.replace(
        {'prognosis': {'Fungal infection': 0, 'Allergy': 1, 'GERD': 2, 'Chronic cholestasis': 3, 'Drug Reaction': 4,
                       'Peptic ulcer diseae': 5, 'AIDS': 6, 'Diabetes ': 7, 'Gastroenteritis': 8, 'Bronchial Asthma': 9,
                       'Hypertension ': 10,
                       'Migraine': 11, 'Cervical spondylosis': 12,
                       'Paralysis (brain hemorrhage)': 13, 'Jaundice': 14, 'Malaria': 15, 'Chicken pox': 16,
                       'Dengue': 17, 'Typhoid': 18, 'hepatitis A': 19,
                       'Hepatitis B': 20, 'Hepatitis C': 21, 'Hepatitis D': 22, 'Hepatitis E': 23,
                       'Alcoholic hepatitis': 24, 'Tuberculosis': 25,
                       'Common Cold': 26, 'Pneumonia': 27, 'Dimorphic hemmorhoids(piles)': 28, 'Heart attack': 29,
                       'Varicose veins': 30, 'Hypothyroidism': 31,
                       'Hyperthyroidism': 32, 'Hypoglycemia': 33, 'Osteoarthristis': 34, 'Arthritis': 35,
                       '(vertigo) Paroymsal  Positional Vertigo': 36, 'Acne': 37, 'Urinary tract infection': 38,
                       'Psoriasis': 39,
                       'Impetigo': 40}}, inplace=True)

    # print(df.head())

    X = df[l1]

    y = df[["prognosis"]]
    np.ravel(y)
    # print(y)

    # Testing DATA
    tr = pd.read_csv("Testing.csv")
    tr.replace(
        {'prognosis': {'Fungal infection': 0, 'Allergy': 1, 'GERD': 2, 'Chronic cholestasis': 3, 'Drug Reaction': 4,
                       'Peptic ulcer diseae': 5, 'AIDS': 6, 'Diabetes ': 7, 'Gastroenteritis': 8, 'Bronchial Asthma': 9,
                       'Hypertension ': 10,
                       'Migraine': 11, 'Cervical spondylosis': 12,
                       'Paralysis (brain hemorrhage)': 13, 'Jaundice': 14, 'Malaria': 15, 'Chicken pox': 16,
                       'Dengue': 17, 'Typhoid': 18, 'hepatitis A': 19,
                       'Hepatitis B': 20, 'Hepatitis C': 21, 'Hepatitis D': 22, 'Hepatitis E': 23,
                       'Alcoholic hepatitis': 24, 'Tuberculosis': 25,
                       'Common Cold': 26, 'Pneumonia': 27, 'Dimorphic hemmorhoids(piles)': 28, 'Heart attack': 29,
                       'Varicose veins': 30, 'Hypothyroidism': 31,
                       'Hyperthyroidism': 32, 'Hypoglycemia': 33, 'Osteoarthristis': 34, 'Arthritis': 35,
                       '(vertigo) Paroymsal  Positional Vertigo': 36, 'Acne': 37, 'Urinary tract infection': 38,
                       'Psoriasis': 39,
                       'Impetigo': 40}}, inplace=True)

    X_test = tr[l1]
    y_test = tr[["prognosis"]]
    np.ravel(y_test)
    # ------------------------------------------------------------------------------------------------------
    def randomforest(psymptoms):
        from sklearn.ensemble import RandomForestClassifier
        clf4 = RandomForestClassifier(n_estimators=100)
        clf4 = clf4.fit(X, y)


        for k in range(0, len(l1)):
            for z in psymptoms:
                if (z == l1[k]):
                    l2[k] = 1

        inputtest = [l2]
        predict = clf4.predict(inputtest)
        predicted = predict[0]

        h = 'no'
        for a in range(0, len(disease)):
            if (predicted == a):
                h = 'yes'
                break
        if (h == 'yes'):
            return disease[a]
        else:
            return "Not Found"
    # symp = [x for x in request.form.values()]
    #id3
    def DecisionTree(psymptoms):
            from sklearn import tree

            clf3 = tree.DecisionTreeClassifier()
            clf3 = clf3.fit(X, y)


            for k in range(0, len(l1)):
                for z in psymptoms:
                    if (z == l1[k]):
                        l2[k] = 1

            inputtest = [l2]
            predict = clf3.predict(inputtest)
            predicted = predict[0]

            h = 'no'
            for a in range(0, len(disease)):
                if (predicted == a):
                    h = 'yes'
                    break

            if (h == 'yes'):
                return disease[a]
            else:
                return "Not Found"

    def KNN(psymptoms):

            from sklearn.neighbors import KNeighborsClassifier
            knn = KNeighborsClassifier(n_neighbors=5, metric='minkowski', p=2)
            knn = knn.fit(X, np.ravel(y))

            for k in range(0, len(l1)):
                for z in psymptoms:
                    if (z == l1[k]):
                        l2[k] = 1

            inputtest = [l2]
            predict = knn.predict(inputtest)
            predicted = predict[0]

            h = 'no'
            for a in range(0, len(disease)):
                if (predicted == a):
                    h = 'yes'
                    break

            if (h == 'yes'):
                return disease[a]
            else:
               return "Not Found"
    #gaussian
    def NaiveBayes(psymptoms):

            from sklearn.naive_bayes import GaussianNB
            gnb = GaussianNB()
            gnb = gnb.fit(X, np.ravel(y))

            for k in range(0, len(l1)):
                for z in psymptoms:
                    if (z == l1[k]):
                        l2[k] = 1

            inputtest = [l2]
            predict = gnb.predict(inputtest)
            predicted = predict[0]

            h = 'no'
            for a in range(0, len(disease)):
                if (predicted == a):
                    h = 'yes'
                    break
            if (h == 'yes'):
                return disease[a]
            else:
                return "Not Found"

    #val1 = request.GET['s1']
    #val2 = request.GET['s2']
    #val3 = request.GET['s3']
    #val4 = request.GET['s4']

    #print(val1,val2,val3,val4)
  
    user_input = request.POST
    data=dict(user_input.lists())
    data.pop('csrfmiddlewaretoken')
    
    symptoms_list=[]
    for k,v in data.items():
        
        symptoms_list.append(k)
    print("this is symptoms_list",symptoms_list)    
    
    
    pred=[NaiveBayes(symptoms_list),KNN(symptoms_list),randomforest(symptoms_list),DecisionTree(symptoms_list)]
    prediction=max(pred, key=pred.count)

    print("this is prediction",prediction)
    
    get_patient_instance=PatientProfile.objects.get(user_id=request.user.id)

    pr=Predict(
        patient   =    get_patient_instance,
        symptoms =    str(symptoms_list),
        Predicted_Disease=prediction,
        predict_date=date.today(),
    )         
    pr.save()
    
    return JsonResponse({'status': 'success','prediction':prediction})
    #return render(request, "Predict/predict.html", {"result2":prediction})


#Predicted Disease End here

